import { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import { Qna } from "../models/QnA";

// ===== 비밀번호 해시 유틸(SHA-256 + salt) =====
function makeSalt(len = 16) {
  return crypto.randomBytes(len).toString("hex");
}

function sha256(text: string) {
  return crypto.createHash("sha256").update(text).digest("hex");
}

/** 저장 포맷: "salt:hash" */
function hashPassword(pw: string) {
  const salt = makeSalt();
  const hash = sha256(`${salt}:${pw}`);
  return `${salt}:${hash}`;
}

function verifyPassword(stored: string | null | undefined, pw: string) {
  if (!stored) return false;
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  return sha256(`${salt}:${pw}`) === hash;
}

function toSafeRow(row: any) {
  // 비밀번호 해시는 응답에서 제거
  const json = row.toJSON ? row.toJSON() : row;
  delete json.passwordHash;
  return json;
}

// =============================
// 1) 목록 GET /api/qna
// query: q, category, answered, page, pageSize
// =============================
export async function listQna(req: Request, res: Response, next: NextFunction) {
  try {
    const q = String(req.query.q ?? "").trim();
    const category = String(req.query.category ?? "").trim();
    const answered = req.query.answered;
    const page = Math.max(1, Number(req.query.page ?? 1));
    const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize ?? 10)));

    const where: any = {};

    if (category) where.category = category;
    if (answered === "true") where.answered = true;
    if (answered === "false") where.answered = false;

    // 검색: question / category like
    if (q) {
      where["$or"] = [
        { question: { $like: `%${q}%` } },
        { category: { $like: `%${q}%` } },
      ];
    }

    // Sequelize v6에서 $like/$or 사용하려면 Op 필요
    // => 아래처럼 Op로 안전하게 처리
    const { Op } = require("sequelize");
    const realWhere: any = {};
    if (category) realWhere.category = category;
    if (answered === "true") realWhere.answered = true;
    if (answered === "false") realWhere.answered = false;
    if (q) {
      realWhere[Op.or] = [
        { question: { [Op.like]: `%${q}%` } },
        { category: { [Op.like]: `%${q}%` } },
      ];
    }

    const offset = (page - 1) * pageSize;

    const { rows, count } = await Qna.findAndCountAll({
      where: realWhere,
      order: [["createdAt", "DESC"]],
      offset,
      limit: pageSize,
      // 목록은 answer는 굳이 안 줘도 됨(원하면 포함 가능)
      attributes: { exclude: ["passwordHash", "answer"] },
    });

    res.json({
      page,
      pageSize,
      total: count,
      totalPages: Math.max(1, Math.ceil(count / pageSize)),
      items: rows.map(toSafeRow),
    });
  } catch (e) {
    next(e);
  }
}

// =============================
// 2) 등록 POST /api/qna
// body: category, question, answer?, isSecret, password?
// =============================
export async function createQna(req: Request, res: Response, next: NextFunction) {
  try {
    const category = String(req.body.category ?? "기타").trim() || "기타";
    const question = String(req.body.question ?? "").trim();
    const answer = req.body.answer == null ? null : String(req.body.answer);
    const isSecret = Boolean(req.body.isSecret);
    const password = String(req.body.password ?? "").trim();

    if (!question) return res.status(400).json({ message: "question은 필수입니다." });
    if (isSecret && !password) {
      return res.status(400).json({ message: "비밀글은 비밀번호가 필요합니다." });
    }

    const answered = !!(answer && String(answer).trim());
    const passwordHash = isSecret ? hashPassword(password) : null;

    const created = await Qna.create({
      category,
      question,
      answer,
      isSecret,
      passwordHash,
      answered,
      views: 0,
      captchaVerifiedAt: null, // 지금은 사용 안 함(추후 서버검증 시 기록)
    });

    res.status(201).json({ item: toSafeRow(created) });
  } catch (e) {
    next(e);
  }
}

// =============================
// 3) 수정 PUT /api/qna/:id
// body: category?, question?, answer?, isSecret?, password(검증용)?, newPassword?
// - 기존이 비밀글이면 password 필수
// - 비밀글로 전환하면 newPassword 필수
// =============================
export async function updateQna(req: Request, res: Response, next: NextFunction) {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).json({ message: "invalid id" });

    const row = await Qna.findByPk(id);
    if (!row) return res.status(404).json({ message: "not found" });

    const password = String(req.body.password ?? "").trim(); // 검증용
    const newPassword = String(req.body.newPassword ?? "").trim(); // 변경용

    // ✅ 기존이 비밀글이면 검증 필수
    if (row.isSecret) {
      if (!password) return res.status(401).json({ message: "비밀번호가 필요합니다." });
      if (!verifyPassword(row.passwordHash, password)) {
        return res.status(403).json({ message: "비밀번호가 일치하지 않습니다." });
      }
    }

    const patch: any = {};
    if (req.body.category !== undefined) patch.category = String(req.body.category ?? "기타").trim() || "기타";
    if (req.body.question !== undefined) {
      const q = String(req.body.question ?? "").trim();
      if (!q) return res.status(400).json({ message: "question은 비어있을 수 없습니다." });
      patch.question = q;
    }
    if (req.body.answer !== undefined) {
      patch.answer = req.body.answer == null ? null : String(req.body.answer);
      patch.answered = !!(patch.answer && String(patch.answer).trim());
    }

    // 비밀글 토글
    if (req.body.isSecret !== undefined) {
      const targetSecret = Boolean(req.body.isSecret);

      // 비밀글로 전환
      if (!row.isSecret && targetSecret) {
        if (!newPassword) {
          return res.status(400).json({ message: "비밀글로 전환 시 newPassword가 필요합니다." });
        }
        patch.isSecret = true;
        patch.passwordHash = hashPassword(newPassword);
      }

      // 공개글로 전환(비번 제거)
      if (row.isSecret && !targetSecret) {
        patch.isSecret = false;
        patch.passwordHash = null;
      }
    }

    // 비밀글 유지하면서 비번 변경
    if (row.isSecret && newPassword) {
      patch.passwordHash = hashPassword(newPassword);
    }

    await row.update(patch);

    res.json({ item: toSafeRow(row) });
  } catch (e) {
    next(e);
  }
}
export async function readQna(req: Request, res: Response, next: NextFunction) {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).json({ message: "invalid id" });

    const row = await Qna.findByPk(id);
    if (!row) return res.status(404).json({ message: "not found" });

    if (row.isSecret) {
      const pw =
        String(req.header("x-qna-password") ?? "").trim() ||
        String(req.query.password ?? "").trim();

        console.log(pw);

      if (!pw) return res.status(401).json({ message: "비밀번호가 필요합니다." });
      if (!verifyPassword(row.passwordHash, pw)) {
        return res.status(403).json({ message: "비밀번호가 일치하지 않습니다." });
      }
    }

    await row.increment("views", { by: 1 });

    res.json(toSafeRow(row));
  } catch (e) {
    next(e);
  }
}

// =============================
// 4) 삭제 DELETE /api/qna/:id
// body: password?  (비밀글이면 필수)
// =============================
export async function deleteQna(req: Request, res: Response, next: NextFunction) {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).json({ message: "invalid id" });

    const row = await Qna.findByPk(id);
    if (!row) return res.status(404).json({ message: "not found" });

    const password = String(req.body.password ?? "").trim();

    if (row.isSecret) {
      if (!password) return res.status(401).json({ message: "비밀번호가 필요합니다." });
      if (!verifyPassword(row.passwordHash, password)) {
        return res.status(403).json({ message: "비밀번호가 일치하지 않습니다." });
      }
    }

    await row.destroy();
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
}
