import { Router } from "express";
import {
  listQna,
  readQna,     // ✅ 추가
  createQna,
  updateQna,
  deleteQna,
} from "../controllers/qna.controller";

const router = Router();

router.get("/", listQna);
router.get("/:id", readQna); // ✅ 상세

router.post("/", createQna);
router.put("/:id", updateQna);
router.delete("/:id", deleteQna);

export default router;
